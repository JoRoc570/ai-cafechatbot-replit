import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Coffee, Settings, Send, Trash2, Bot, Search, History, Moon, Sun, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { CoffeeLoader } from "@/components/CoffeeLoader";
import { ChatSearch } from "@/components/ChatSearch";
import { MessageReactions } from "@/components/MessageReactions";
import { VoiceInput } from "@/components/VoiceInput";
import { DynamicQuickActions } from "@/components/DynamicQuickActions";
import { ChatHistory } from "@/components/ChatHistory";
import { EnhancedSettings } from "@/components/EnhancedSettings";
import { useChatHistory } from "@/hooks/useChatHistory";
import { useTheme } from "@/components/ThemeProvider";

interface ChatMessage {
  id: number;
  sessionId: string;
  message: string;
  isUser: boolean;
  timestamp: string;
  reaction?: 'helpful' | 'unhelpful';
}

export default function Chat() {
  const [sessionId, setSessionId] = useState(() => `session-${Date.now()}-${Math.random()}`);
  const [message, setMessage] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("openai-api-key") || "");
  const [isOnline, setIsOnline] = useState(true);
  const [estimatedResponseTime, setEstimatedResponseTime] = useState(2);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const { 
    chatHistory, 
    saveSession, 
    searchMessages, 
    updateMessageReaction 
  } = useChatHistory();

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Fetch chat messages
  const { data: messagesData } = useQuery({
    queryKey: ["/api/chat", sessionId],
    enabled: !!sessionId,
  });

  const messages = (messagesData as { messages: ChatMessage[] } | undefined)?.messages || [];

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const startTime = Date.now();
      const response = await apiRequest("POST", "/api/chat", {
        message: messageText,
        sessionId,
      });
      const endTime = Date.now();
      const responseTime = (endTime - startTime) / 1000;
      
      // Update estimated response time
      setEstimatedResponseTime(Math.round(responseTime));
      
      return await response.json();
    },
    onSuccess: (data, messageText) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat", sessionId] });
      
      // Save to chat history
      const currentMessages = (messagesData as { messages: ChatMessage[] } | undefined)?.messages || [];
      const newMessages = [
        ...currentMessages,
        data.userMessage,
        data.aiMessage
      ];
      saveSession(sessionId, newMessages);
      
      setMessage("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
      
      // Play success sound if enabled
      const soundEnabled = localStorage.getItem("cafe-sound-enabled") !== "false";
      if (soundEnabled) {
        playNotificationSound();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Brewing Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
      setIsOnline(false);
      setTimeout(() => setIsOnline(true), 3000);
    },
  });

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  // Additional utility functions
  const playNotificationSound = () => {
    try {
      const audio = new Audio('/notification.mp3'); // Will fallback gracefully if not found
      audio.volume = 0.3;
      audio.play().catch(() => {}); // Ignore errors
    } catch (error) {
      // Graceful fallback
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      // Show all current messages when search is cleared
      return;
    }
    // Search functionality will filter messages in display
  };

  const handleLoadSession = (sessionId: string) => {
    setSessionId(sessionId);
    queryClient.invalidateQueries({ queryKey: ["/api/chat", sessionId] });
  };

  const handleReaction = (messageId: number, reaction: 'helpful' | 'unhelpful') => {
    updateMessageReaction(sessionId, messageId, reaction);
    toast({
      title: "Feedback received",
      description: "Thank you for rating this response!",
    });
  };

  const handleVoiceTranscript = (transcript: string) => {
    setMessage(transcript);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Handle quick question buttons
  const handleQuickQuestion = (question: string) => {
    if (!sendMessageMutation.isPending) {
      sendMessageMutation.mutate(question);
    }
  };

  // Auto-resize textarea
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
  };

  // Handle Enter key
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  // Clear chat
  const clearChat = () => {
    queryClient.setQueryData(["/api/chat", sessionId], { messages: [] });
    setSearchQuery("");
    toast({
      title: "Chat cleared",
      description: "Your conversation has been reset",
    });
  };



  // Format timestamp with enhanced formatting
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    
    if (diffMinutes < 1) return "just now";
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    return date.toLocaleDateString();
  };

  // Auto-scroll when new messages arrive
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Filter messages based on search query
  const filteredMessages = searchQuery.trim() 
    ? messages.filter(msg => 
        msg.message.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : messages;

  return (
    <div className="min-h-screen flex flex-col bg-cream">
      {/* Header */}
      <header className="bg-white shadow-md border-b border-gray-200 px-4 py-3 sm:px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 coffee-brown rounded-full flex items-center justify-center">
              <Coffee className="text-white" size={20} />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Bean & Brew Café</h1>
              <p className="text-sm text-gray-600 flex items-center">
                <span className={cn("w-2 h-2 rounded-full mr-2", isOnline ? "bg-green-500" : "bg-red-500")}></span>
                <span>{isOnline ? "AI Assistant Online" : "Connection Issues"}</span>
              </p>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSettings(true)}
            className="p-2 text-gray-500 hover:text-gray-700"
          >
            <Settings size={20} />
          </Button>
        </div>
      </header>

      {/* Main Chat Container */}
      <main className="flex-1 flex flex-col max-w-4xl mx-auto w-full px-4 sm:px-6">
        
        {/* Welcome Message */}
        <div className="py-6">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 animate-fade-in">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 coffee-brown rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-white" size={20} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-medium text-gray-900 mb-2">Welcome to Bean & Brew Café! ☕</h2>
                <p className="text-gray-600 mb-4">I'm your AI assistant, here to help with any questions about our menu, hours, location, or services. What would you like to know?</p>
                
                {/* Dynamic Quick action buttons */}
                <DynamicQuickActions 
                  onQuickQuestion={handleQuickQuestion}
                  disabled={sendMessageMutation.isPending}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 mb-6 space-y-4">
          {messages.map((msg: ChatMessage) => (
            <div
              key={msg.id}
              className={cn(
                "flex animate-slide-up",
                msg.isUser ? "justify-end" : "justify-start"
              )}
            >
              {msg.isUser ? (
                <div className="max-w-xs lg:max-w-md">
                  <div className="coffee-brown text-white rounded-2xl rounded-br-md px-4 py-3 shadow-sm">
                    <p className="text-sm">{msg.message}</p>
                  </div>
                  <div className="text-xs text-gray-500 mt-1 text-right">{formatTime(msg.timestamp)}</div>
                </div>
              ) : (
                <div className="max-w-xs lg:max-w-md">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 coffee-brown rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="text-white" size={14} />
                    </div>
                    <div>
                      <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
                        <p className="text-sm text-gray-800 whitespace-pre-wrap">{msg.message}</p>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">{formatTime(msg.timestamp)}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Loading State */}
          {sendMessageMutation.isPending && (
            <div className="flex justify-start animate-slide-up">
              <div className="max-w-xs lg:max-w-md">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 coffee-brown rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="text-white" size={14} />
                  </div>
                  <div>
                    <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full bounce-dot-1"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full bounce-dot-2"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full bounce-dot-3"></div>
                        <span className="text-sm text-gray-500 ml-2">Brewing your answer...</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Chat Input */}
      <footer className="bg-white border-t border-gray-200 px-4 py-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="flex items-end space-x-3">
            <div className="flex-1 relative">
              <Textarea
                ref={textareaRef}
                value={message}
                onChange={handleTextareaChange}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything about Bean & Brew Café..."
                className="resize-none pr-12 rounded-2xl border-gray-300 focus:border-coffee focus:ring-coffee"
                rows={1}
              />
              <Button
                type="submit"
                size="sm"
                disabled={!message.trim() || sendMessageMutation.isPending}
                className="absolute bottom-2 right-2 w-8 h-8 coffee-brown hover:coffee-brown-hover rounded-full p-0"
              >
                <Send size={14} />
              </Button>
            </div>
          </form>
          
          <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
            <span>Powered by OpenAI • {sendMessageMutation.isPending ? "Responding..." : "~2s response time"}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearChat}
              className="text-coffee hover:text-coffee/80 p-0 h-auto"
            >
              <Trash2 className="mr-1" size={12} /> Clear chat
            </Button>
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Chat Settings
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(false)}
                className="p-0 h-auto"
              >
                <X size={20} />
              </Button>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="apiKey" className="text-sm font-medium mb-2 block">
                OpenAI API Key
              </Label>
              <Input
                id="apiKey"
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className="focus:ring-coffee focus:border-coffee"
              />
              <p className="text-xs text-gray-500 mt-1">Your API key is stored securely in your browser</p>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">AI Model</Label>
              <Select defaultValue="gpt-4o">
                <SelectTrigger className="focus:ring-coffee focus:border-coffee">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gpt-4o">GPT-4o (Latest)</SelectItem>
                  <SelectItem value="gpt-4">GPT-4 (More Accurate)</SelectItem>
                  <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo (Faster)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Response Style</Label>
              <Select defaultValue="friendly">
                <SelectTrigger className="focus:ring-coffee focus:border-coffee">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="friendly">Friendly & Casual</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="detailed">Detailed & Informative</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex space-x-3 mt-6">
            <Button onClick={saveSettings} className="flex-1 coffee-brown hover:coffee-brown-hover">
              <CheckCircle className="mr-2" size={16} />
              Save Settings
            </Button>
            <Button variant="outline" onClick={() => setShowSettings(false)} className="flex-1">
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
