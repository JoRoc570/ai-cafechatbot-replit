import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Coffee, Settings, Send, Trash2, Bot, Search, History, Moon, Sun, Download, Clock, Utensils, MapPin, Wifi, ThumbsUp, ThumbsDown, Mic, BarChart3, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { ChatAnalytics } from "@/components/ChatAnalytics";
import { LanguageSelector, useTranslations } from "@/components/LanguageSelector";
import { useTheme } from "@/components/ThemeProvider";

interface ChatMessage {
  id: number;
  sessionId: string;
  message: string;
  isUser: boolean;
  timestamp: string;
  reaction?: 'helpful' | 'unhelpful';
}

export default function EnhancedChat() {
  const [sessionId] = useState(() => `session-${Date.now()}-${Math.random()}`);
  const [message, setMessage] = useState("");
  const [isOnline, setIsOnline] = useState(true);
  const [estimatedResponseTime, setEstimatedResponseTime] = useState(2);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(() => 
    localStorage.getItem("cafe-language") || "en"
  );
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const { t } = useTranslations(selectedLanguage);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Fetch chat messages
  const { data: messagesData } = useQuery({
    queryKey: ["/api/chat", sessionId],
    enabled: !!sessionId,
  });

  const messages = (messagesData as { messages: ChatMessage[] } | undefined)?.messages || [];

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const startTime = Date.now();
      const response = await apiRequest("POST", "/api/chat", {
        message: messageText,
        sessionId,
      });
      const endTime = Date.now();
      const responseTime = (endTime - startTime) / 1000;
      
      setEstimatedResponseTime(Math.round(responseTime));
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat", sessionId] });
      setMessage("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Brewing Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
      setIsOnline(false);
      setTimeout(() => setIsOnline(true), 3000);
    },
  });

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  // Handle quick question buttons
  const handleQuickQuestion = (question: string) => {
    if (!sendMessageMutation.isPending) {
      sendMessageMutation.mutate(question);
    }
  };

  // Auto-resize textarea
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
  };

  // Handle Enter key
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  // Format timestamp with enhanced formatting
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    
    if (diffMinutes < 1) return "just now";
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    return date.toLocaleDateString();
  };

  // Handle language change
  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    localStorage.setItem("cafe-language", language);
  };

  // Get time-based quick actions with translations
  const getQuickActions = () => {
    const currentHour = new Date().getHours();
    
    if (currentHour >= 6 && currentHour < 11) {
      return [
        { icon: Coffee, label: t("breakfast"), question: `What ${t("breakfast").toLowerCase()} items do you have?` },
        { icon: Clock, label: t("hours"), question: `What are your ${t("hours").toLowerCase()}?` },
        { icon: Coffee, label: t("coffee"), question: `What ${t("coffee").toLowerCase()} drinks do you make?` },
        { icon: Wifi, label: t("wifi"), question: `Do you have ${t("wifi")}?` }
      ];
    } else if (currentHour >= 11 && currentHour < 15) {
      return [
        { icon: Utensils, label: t("lunch"), question: `What ${t("lunch").toLowerCase()} options do you have?` },
        { icon: MapPin, label: t("location"), question: `Where are you located?` },
        { icon: Clock, label: t("studySpace"), question: `Do you have study areas?` },
        { icon: Coffee, label: t("payment"), question: `What payment methods do you accept?` }
      ];
    } else {
      return [
        { icon: Clock, label: t("hours"), question: `What are your ${t("hours").toLowerCase()}?` },
        { icon: Utensils, label: t("menu"), question: `What's on your ${t("menu").toLowerCase()}?` },
        { icon: MapPin, label: t("location"), question: `Where are you located?` },
        { icon: Wifi, label: t("wifi"), question: `Do you have ${t("wifi")}?` }
      ];
    }
  };

  // Auto-scroll when new messages arrive
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="min-h-screen flex flex-col bg-cream dark:bg-gray-900">
      {/* Enhanced Header */}
      <header className="bg-white dark:bg-gray-800 shadow-md border-b border-gray-200 dark:border-gray-700 px-4 py-3 sm:px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 coffee-brown rounded-full flex items-center justify-center animate-pulse-coffee">
              <Coffee className="text-white" size={20} />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Bean & Brew Café</h1>
              <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center">
                <span className={cn("w-2 h-2 rounded-full mr-2", isOnline ? "bg-green-500" : "bg-red-500")}></span>
                <span>{isOnline ? `AI Assistant Online • ~${estimatedResponseTime}s response` : "Connection Issues"}</span>
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <LanguageSelector
              selectedLanguage={selectedLanguage}
              onLanguageChange={handleLanguageChange}
              compact
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            >
              <Search size={18} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            >
              <History size={18} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAnalytics(true)}
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            >
              <BarChart3 size={18} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            >
              <Settings size={18} />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Chat Container */}
      <main className="flex-1 flex flex-col max-w-4xl mx-auto w-full px-4 sm:px-6">
        
        {/* Enhanced Welcome Message */}
        <div className="py-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 animate-fade-in glass-effect">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 coffee-brown rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-white" size={20} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-2">{t("welcome")}</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-4">{t("welcomeText")}</p>
                
                {/* Dynamic Quick action buttons */}
                <div className="flex flex-wrap gap-2">
                  {getQuickActions().map((action, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => handleQuickQuestion(action.question)}
                      disabled={sendMessageMutation.isPending}
                      className="px-3 py-2 text-sm hover:bg-coffee/10 hover:border-coffee transition-colors"
                    >
                      <action.icon className="mr-1" size={14} />
                      {action.label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Chat Messages */}
        <div className="flex-1 mb-6 space-y-4">
          {messages.map((msg: ChatMessage) => (
            <div
              key={msg.id}
              className={cn(
                "flex group",
                msg.isUser ? "justify-end animate-slide-in-right" : "justify-start animate-slide-in-left"
              )}
            >
              {msg.isUser ? (
                <div className="max-w-xs lg:max-w-md">
                  <div className="coffee-brown text-white rounded-2xl rounded-br-md px-4 py-3 shadow-sm message-text">
                    <p className="text-sm">{msg.message}</p>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-1 text-right">{formatTime(msg.timestamp)}</div>
                </div>
              ) : (
                <div className="max-w-xs lg:max-w-md">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 coffee-brown rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="text-white" size={14} />
                    </div>
                    <div className="flex-1">
                      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
                        <p className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap message-text">{msg.message}</p>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <div className="text-xs text-gray-500 dark:text-gray-400">{formatTime(msg.timestamp)}</div>
                        {/* Message reactions */}
                        <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1 h-auto text-xs text-gray-400 hover:text-green-600"
                          >
                            <ThumbsUp size={12} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1 h-auto text-xs text-gray-400 hover:text-red-600"
                          >
                            <ThumbsDown size={12} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Enhanced Loading State */}
          {sendMessageMutation.isPending && (
            <div className="flex justify-start animate-slide-in-left">
              <div className="max-w-xs lg:max-w-md">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 coffee-brown rounded-full flex items-center justify-center flex-shrink-0 animate-pulse">
                    <Bot className="text-white" size={14} />
                  </div>
                  <div>
                    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
                      <div className="flex items-center space-x-3">
                        <Coffee className="w-6 h-6 text-coffee animate-bounce" />
                        <span className="text-sm text-gray-500 dark:text-gray-400">{t("brewing")}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Enhanced Chat Input */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="flex items-end space-x-3">
            <div className="flex-1 relative enhanced-focus">
              <Textarea
                ref={textareaRef}
                value={message}
                onChange={handleTextareaChange}
                onKeyDown={handleKeyDown}
                placeholder={t("placeholder")}
                className="resize-none pr-20 rounded-2xl border-gray-300 dark:border-gray-600 focus:border-coffee focus:ring-coffee dark:bg-gray-700 dark:text-white message-text"
                rows={1}
              />
              <div className="absolute bottom-2 right-2 flex items-center space-x-1">
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="p-2 rounded-full text-coffee hover:text-coffee/80 hover:bg-coffee/10"
                >
                  <Mic size={14} />
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  disabled={!message.trim() || sendMessageMutation.isPending}
                  className="w-8 h-8 coffee-brown hover:coffee-brown-hover rounded-full p-0"
                >
                  <Send size={14} />
                </Button>
              </div>
            </div>
          </form>
          
          <div className="flex items-center justify-between mt-3 text-xs text-gray-500 dark:text-gray-400">
            <span>Powered by OpenAI • {sendMessageMutation.isPending ? `${t("brewing")} (~${estimatedResponseTime}s)...` : `~${estimatedResponseTime}s response time`}</span>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="text-coffee hover:text-coffee/80 p-0 h-auto flex items-center space-x-1"
              >
                <Download size={12} />
                <span>Export</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => queryClient.setQueryData(["/api/chat", sessionId], { messages: [] })}
                className="text-coffee hover:text-coffee/80 p-0 h-auto flex items-center space-x-1"
              >
                <Trash2 size={12} />
                <span>Clear chat</span>
              </Button>
            </div>
          </div>
        </div>
      </footer>

      {/* Analytics Modal */}
      <ChatAnalytics isOpen={showAnalytics} onClose={() => setShowAnalytics(false)} />
    </div>
  );
}