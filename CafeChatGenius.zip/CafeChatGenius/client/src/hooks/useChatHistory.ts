import { useLocalStorage } from "./useLocalStorage";

interface ChatMessage {
  id: number;
  sessionId: string;
  message: string;
  isUser: boolean;
  timestamp: string;
  reaction?: 'helpful' | 'unhelpful';
}

interface ChatSession {
  sessionId: string;
  messages: ChatMessage[];
  createdAt: string;
  title?: string;
}

export function useChatHistory() {
  const [chatHistory, setChatHistory] = useLocalStorage<ChatSession[]>("cafe-chat-history", []);

  const saveSession = (sessionId: string, messages: ChatMessage[]) => {
    if (messages.length === 0) return;

    const existingIndex = chatHistory.findIndex(session => session.sessionId === sessionId);
    const title = generateSessionTitle(messages);
    
    const session: ChatSession = {
      sessionId,
      messages,
      createdAt: new Date().toISOString(),
      title
    };

    if (existingIndex >= 0) {
      const updatedHistory = [...chatHistory];
      updatedHistory[existingIndex] = session;
      setChatHistory(updatedHistory);
    } else {
      setChatHistory([session, ...chatHistory]);
    }
  };

  const deleteSession = (sessionId: string) => {
    setChatHistory(chatHistory.filter(session => session.sessionId !== sessionId));
  };

  const clearAllHistory = () => {
    setChatHistory([]);
  };

  const searchMessages = (query: string): ChatMessage[] => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    const allMessages: ChatMessage[] = [];
    
    chatHistory.forEach(session => {
      session.messages.forEach(message => {
        if (message.message.toLowerCase().includes(lowerQuery)) {
          allMessages.push(message);
        }
      });
    });
    
    return allMessages.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  };

  const updateMessageReaction = (sessionId: string, messageId: number, reaction: 'helpful' | 'unhelpful') => {
    setChatHistory(prevHistory => 
      prevHistory.map(session => {
        if (session.sessionId !== sessionId) return session;
        
        return {
          ...session,
          messages: session.messages.map(msg => 
            msg.id === messageId ? { ...msg, reaction } : msg
          )
        };
      })
    );
  };

  return {
    chatHistory,
    saveSession,
    deleteSession,
    clearAllHistory,
    searchMessages,
    updateMessageReaction
  };
}

function generateSessionTitle(messages: ChatMessage[]): string {
  const userMessages = messages.filter(m => m.isUser);
  if (userMessages.length === 0) return "New Chat";
  
  const firstMessage = userMessages[0].message;
  if (firstMessage.length <= 30) return firstMessage;
  
  return firstMessage.substring(0, 27) + "...";
}