import { Coffee } from "lucide-react";
import { cn } from "@/lib/utils";

interface CoffeeLoaderProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  text?: string;
}

export function CoffeeLoader({ className, size = "md", text = "Brewing your answer..." }: CoffeeLoaderProps) {
  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-8 h-8", 
    lg: "w-12 h-12"
  };

  const textSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base"
  };

  return (
    <div className={cn("flex items-center space-x-3", className)}>
      <div className="relative">
        <Coffee 
          className={cn(
            sizeClasses[size],
            "text-coffee animate-bounce"
          )}
          style={{
            animationDelay: "0s",
            animationDuration: "1s"
          }}
        />
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-amber-400 rounded-full animate-ping opacity-75"></div>
      </div>
      <span className={cn("text-gray-500", textSizeClasses[size])}>{text}</span>
    </div>
  );
}