import { useState } from "react";
import { ThumbsUp, ThumbsDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface MessageReactionsProps {
  messageId: number;
  onReaction: (messageId: number, reaction: 'helpful' | 'unhelpful') => void;
  initialReaction?: 'helpful' | 'unhelpful' | null;
}

export function MessageReactions({ messageId, onReaction, initialReaction = null }: MessageReactionsProps) {
  const [reaction, setReaction] = useState<'helpful' | 'unhelpful' | null>(initialReaction);

  const handleReaction = (type: 'helpful' | 'unhelpful') => {
    const newReaction = reaction === type ? null : type;
    setReaction(newReaction);
    if (newReaction) {
      onReaction(messageId, newReaction);
    }
  };

  return (
    <div className="flex items-center space-x-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => handleReaction('helpful')}
        className={cn(
          "p-1 h-auto text-xs",
          reaction === 'helpful' ? "text-green-600 bg-green-50" : "text-gray-400 hover:text-green-600"
        )}
      >
        <ThumbsUp size={12} />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => handleReaction('unhelpful')}
        className={cn(
          "p-1 h-auto text-xs",
          reaction === 'unhelpful' ? "text-red-600 bg-red-50" : "text-gray-400 hover:text-red-600"
        )}
      >
        <ThumbsDown size={12} />
      </Button>
    </div>
  );
}