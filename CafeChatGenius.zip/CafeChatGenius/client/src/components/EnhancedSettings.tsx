import { useState } from "react";
import { X, CheckCircle, Moon, Sun, Palette, Type, Volume2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useTheme } from "@/components/ThemeProvider";

interface EnhancedSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  setApiKey: (key: string) => void;
}

export function EnhancedSettings({ isOpen, onClose, apiKey, setApiKey }: EnhancedSettingsProps) {
  const { theme, toggleTheme } = useTheme();
  const [fontSize, setFontSize] = useState(() => 
    parseInt(localStorage.getItem("cafe-font-size") || "14")
  );
  const [soundEnabled, setSoundEnabled] = useState(() => 
    localStorage.getItem("cafe-sound-enabled") !== "false"
  );
  const [voiceEnabled, setVoiceEnabled] = useState(() => 
    localStorage.getItem("cafe-voice-enabled") !== "false"
  );
  const [colorScheme, setColorScheme] = useState(() => 
    localStorage.getItem("cafe-color-scheme") || "classic"
  );
  const [language, setLanguage] = useState(() => 
    localStorage.getItem("cafe-language") || "en"
  );

  const saveSettings = () => {
    localStorage.setItem("openai-api-key", apiKey);
    localStorage.setItem("cafe-font-size", fontSize.toString());
    localStorage.setItem("cafe-sound-enabled", soundEnabled.toString());
    localStorage.setItem("cafe-voice-enabled", voiceEnabled.toString());
    localStorage.setItem("cafe-color-scheme", colorScheme);
    localStorage.setItem("cafe-language", language);
    
    // Apply font size
    document.documentElement.style.setProperty("--chat-font-size", `${fontSize}px`);
    
    onClose();
  };

  const exportChatData = () => {
    const chatHistory = localStorage.getItem("cafe-chat-history");
    if (chatHistory) {
      const blob = new Blob([chatHistory], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `bean-brew-chat-history-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Settings & Preferences
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="p-0 h-auto"
            >
              <X size={20} />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* API Configuration */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">API Configuration</Label>
            <div>
              <Label htmlFor="apiKey" className="text-sm font-medium mb-2 block">
                OpenAI API Key
              </Label>
              <Input
                id="apiKey"
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className="focus:ring-coffee focus:border-coffee"
              />
              <p className="text-xs text-gray-500 mt-1">Your API key is stored securely in your browser</p>
            </div>
          </div>

          {/* Appearance */}
          <div className="space-y-3">
            <Label className="text-base font-semibold flex items-center">
              <Palette className="mr-2" size={16} />
              Appearance
            </Label>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Dark Mode</Label>
              <div className="flex items-center space-x-2">
                <Sun size={16} />
                <Switch
                  checked={theme === 'dark'}
                  onCheckedChange={toggleTheme}
                />
                <Moon size={16} />
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Color Scheme</Label>
              <Select value={colorScheme} onValueChange={setColorScheme}>
                <SelectTrigger className="focus:ring-coffee focus:border-coffee">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="classic">Classic Coffee</SelectItem>
                  <SelectItem value="warm">Warm Autumn</SelectItem>
                  <SelectItem value="cool">Cool Mint</SelectItem>
                  <SelectItem value="vibrant">Vibrant Berry</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium mb-3 block flex items-center">
                <Type className="mr-2" size={14} />
                Font Size: {fontSize}px
              </Label>
              <Slider
                value={[fontSize]}
                onValueChange={(value) => setFontSize(value[0])}
                max={20}
                min={12}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          {/* Audio & Voice */}
          <div className="space-y-3">
            <Label className="text-base font-semibold flex items-center">
              <Volume2 className="mr-2" size={16} />
              Audio & Voice
            </Label>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Sound Notifications</Label>
              <Switch
                checked={soundEnabled}
                onCheckedChange={setSoundEnabled}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Voice Input</Label>
              <Switch
                checked={voiceEnabled}
                onCheckedChange={setVoiceEnabled}
              />
            </div>
          </div>

          {/* Language */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Language</Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="focus:ring-coffee focus:border-coffee">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="de">Deutsch</SelectItem>
                <SelectItem value="it">Italiano</SelectItem>
                <SelectItem value="pt">Português</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* AI Behavior */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">AI Assistant</Label>
            <div>
              <Label className="text-sm font-medium mb-2 block">Response Style</Label>
              <Select defaultValue="friendly">
                <SelectTrigger className="focus:ring-coffee focus:border-coffee">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="friendly">Friendly & Casual</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="detailed">Detailed & Informative</SelectItem>
                  <SelectItem value="concise">Brief & Direct</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Data Management */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Data Management</Label>
            <Button
              variant="outline"
              onClick={exportChatData}
              className="w-full flex items-center justify-center"
            >
              <Download className="mr-2" size={16} />
              Export Chat History
            </Button>
          </div>
        </div>

        <div className="flex space-x-3 mt-6">
          <Button onClick={saveSettings} className="flex-1 coffee-brown hover:coffee-brown-hover">
            <CheckCircle className="mr-2" size={16} />
            Save Settings
          </Button>
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}