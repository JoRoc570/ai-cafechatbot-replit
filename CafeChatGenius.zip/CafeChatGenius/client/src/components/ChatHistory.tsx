import { useState } from "react";
import { Clock, Trash2, MessageSquare, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useChatHistory } from "@/hooks/useChatHistory";

interface ChatHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadSession: (sessionId: string) => void;
}

export function ChatHistory({ isOpen, onClose, onLoadSession }: ChatHistoryProps) {
  const { chatHistory, deleteSession, clearAllHistory } = useChatHistory();
  const [confirmingClear, setConfirmingClear] = useState(false);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return "Today";
    if (diffDays === 2) return "Yesterday";
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    
    return date.toLocaleDateString();
  };

  const handleLoadSession = (sessionId: string) => {
    onLoadSession(sessionId);
    onClose();
  };

  const handleClearAll = () => {
    clearAllHistory();
    setConfirmingClear(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Chat History
            <div className="flex items-center space-x-2">
              {chatHistory.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setConfirmingClear(true)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 size={16} />
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="p-0 h-auto"
              >
                <X size={20} />
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh]">
          {chatHistory.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <MessageSquare className="mx-auto mb-4 opacity-50" size={48} />
              <p>No chat history yet</p>
              <p className="text-sm">Start a conversation to see it here</p>
            </div>
          ) : (
            <div className="space-y-2">
              {chatHistory.map((session) => (
                <div
                  key={session.sessionId}
                  className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer group"
                  onClick={() => handleLoadSession(session.sessionId)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">
                        {session.title || "Untitled Chat"}
                      </h4>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Clock size={12} className="mr-1" />
                        {formatDate(session.createdAt)}
                        <span className="mx-2">•</span>
                        {session.messages.length} messages
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteSession(session.sessionId);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 h-auto text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Confirm Clear All Dialog */}
        <Dialog open={confirmingClear} onOpenChange={setConfirmingClear}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>Clear All History?</DialogTitle>
            </DialogHeader>
            <p className="text-sm text-gray-600 mb-4">
              This will permanently delete all your chat history. This action cannot be undone.
            </p>
            <div className="flex space-x-2">
              <Button
                variant="destructive"
                onClick={handleClearAll}
                className="flex-1"
              >
                Clear All
              </Button>
              <Button
                variant="outline"
                onClick={() => setConfirmingClear(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}