import * as Icons from "lucide-react";
import { Button } from "@/components/ui/button";

interface QuickAction {
  icon: keyof typeof Icons;
  label: string;
  question: string;
}

interface DynamicQuickActionsProps {
  onQuickQuestion: (question: string) => void;
  disabled?: boolean;
}

export function DynamicQuickActions({ onQuickQuestion, disabled = false }: DynamicQuickActionsProps) {
  const currentHour = new Date().getHours();
  
  const getTimeBasedActions = (): QuickAction[] => {
    if (currentHour >= 6 && currentHour < 11) {
      // Morning - breakfast focused
      return [
        { icon: "Coffee", label: "Breakfast", question: "What breakfast items do you have?" },
        { icon: "Clock", label: "Hours", question: "What are your hours?" },
        { icon: "Coffee", label: "Coffee", question: "What coffee drinks do you make?" },
        { icon: "Wifi", label: "WiFi", question: "Do you have WiFi?" }
      ];
    } else if (currentHour >= 11 && currentHour < 15) {
      // Lunch time
      return [
        { icon: "Utensils", label: "Lunch", question: "What lunch options do you have?" },
        { icon: "MapPin", label: "Location", question: "Where are you located?" },
        { icon: "Users", label: "Study Space", question: "Do you have study areas?" },
        { icon: "CreditCard", label: "Payment", question: "What payment methods do you accept?" }
      ];
    } else if (currentHour >= 15 && currentHour < 18) {
      // Afternoon - study focused
      return [
        { icon: "Users", label: "Study Rooms", question: "Can I reserve a study room?" },
        { icon: "Coffee", label: "Afternoon Drinks", question: "What cold drinks do you have?" },
        { icon: "Wifi", label: "WiFi", question: "What's the WiFi password?" },
        { icon: "Calendar", label: "Events", question: "Do you have any events coming up?" }
      ];
    } else {
      // Evening/night
      return [
        { icon: "Calendar", label: "Events", question: "Do you have evening events?" },
        { icon: "Clock", label: "Hours", question: "How late are you open?" },
        { icon: "Coffee", label: "Decaf Options", question: "Do you have decaf options?" },
        { icon: "MapPin", label: "Parking", question: "Is there parking available?" }
      ];
    }
  };

  const actions = getTimeBasedActions();

  return (
    <div className="flex flex-wrap gap-2">
      {actions.map((action, index) => {
        const IconComponent = Icons[action.icon] as React.ComponentType<{ size?: number; className?: string }>;
        return (
          <Button
            key={index}
            variant="outline"
            size="sm"
            onClick={() => onQuickQuestion(action.question)}
            disabled={disabled}
            className="px-3 py-2 text-sm hover:bg-coffee/10 hover:border-coffee transition-colors"
          >
            <IconComponent className="mr-1" size={14} />
            {action.label}
          </Button>
        );
      })}
    </div>
  );
}