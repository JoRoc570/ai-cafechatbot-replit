import { useState } from "react";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface ChatSearchProps {
  onSearch: (query: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function ChatSearch({ onSearch, isOpen, onClose }: ChatSearchProps) {
  const [query, setQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const handleClear = () => {
    setQuery("");
    onSearch("");
  };

  if (!isOpen) return null;

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-3 animate-slide-up">
      <form onSubmit={handleSearch} className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <Input
            type="text"
            placeholder="Search messages..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-10 focus:ring-coffee focus:border-coffee"
            autoFocus
          />
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 h-auto"
            >
              <X size={14} />
            </Button>
          )}
        </div>
        <Button
          type="button"
          variant="ghost"
          onClick={onClose}
          className="text-coffee hover:text-coffee/80"
        >
          Close
        </Button>
      </form>
    </div>
  );
}