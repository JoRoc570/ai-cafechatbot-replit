import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, MessageSquare, Clock, X } from "lucide-react";

interface ChatAnalyticsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatAnalytics({ isOpen, onClose }: ChatAnalyticsProps) {
  const [analytics, setAnalytics] = useState({
    totalSessions: 0,
    totalMessages: 0,
    averageSessionLength: 0,
    topQuestions: [] as { question: string; count: number }[],
    hourlyUsage: [] as { hour: string; messages: number }[],
    dailyUsage: [] as { day: string; messages: number }[],
    responseRatings: [] as { rating: string; count: number }[]
  });

  useEffect(() => {
    if (isOpen) {
      generateAnalytics();
    }
  }, [isOpen]);

  const generateAnalytics = () => {
    try {
      const chatHistory = localStorage.getItem("cafe-chat-history");
      if (!chatHistory) {
        setAnalytics(prev => ({ ...prev }));
        return;
      }

      const history = JSON.parse(chatHistory);
      const totalSessions = history.length;
      
      let totalMessages = 0;
      const questionCounts: { [key: string]: number } = {};
      const hourCounts: { [key: string]: number } = {};
      const dayCounts: { [key: string]: number } = {};
      const ratingCounts = { helpful: 0, unhelpful: 0, noRating: 0 };

      history.forEach((session: any) => {
        totalMessages += session.messages.length;
        
        session.messages.forEach((msg: any) => {
          const date = new Date(msg.timestamp);
          const hour = date.getHours().toString().padStart(2, '0') + ':00';
          const day = date.toLocaleDateString('en-US', { weekday: 'short' });
          
          hourCounts[hour] = (hourCounts[hour] || 0) + 1;
          dayCounts[day] = (dayCounts[day] || 0) + 1;
          
          if (msg.isUser) {
            const question = msg.message.toLowerCase();
            if (question.includes('menu') || question.includes('food')) {
              questionCounts['Menu & Food'] = (questionCounts['Menu & Food'] || 0) + 1;
            } else if (question.includes('hour') || question.includes('open')) {
              questionCounts['Hours'] = (questionCounts['Hours'] || 0) + 1;
            } else if (question.includes('location') || question.includes('where')) {
              questionCounts['Location'] = (questionCounts['Location'] || 0) + 1;
            } else if (question.includes('wifi') || question.includes('internet')) {
              questionCounts['WiFi'] = (questionCounts['WiFi'] || 0) + 1;
            } else {
              questionCounts['Other'] = (questionCounts['Other'] || 0) + 1;
            }
          }

          if (msg.reaction === 'helpful') ratingCounts.helpful++;
          else if (msg.reaction === 'unhelpful') ratingCounts.unhelpful++;
          else ratingCounts.noRating++;
        });
      });

      const topQuestions = Object.entries(questionCounts)
        .map(([question, count]) => ({ question, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      const hourlyUsage = Array.from({ length: 24 }, (_, i) => ({
        hour: i.toString().padStart(2, '0') + ':00',
        messages: hourCounts[i.toString().padStart(2, '0') + ':00'] || 0
      }));

      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const dailyUsage = days.map(day => ({
        day,
        messages: dayCounts[day] || 0
      }));

      const responseRatings = [
        { rating: 'Helpful', count: ratingCounts.helpful },
        { rating: 'Unhelpful', count: ratingCounts.unhelpful },
        { rating: 'No Rating', count: ratingCounts.noRating }
      ];

      setAnalytics({
        totalSessions,
        totalMessages,
        averageSessionLength: totalSessions > 0 ? Math.round(totalMessages / totalSessions) : 0,
        topQuestions,
        hourlyUsage,
        dailyUsage,
        responseRatings
      });
    } catch (error) {
      console.error('Failed to generate analytics:', error);
    }
  };

  const COLORS = ['#8B4513', '#D2691E', '#CD853F', '#DEB887', '#F4A460'];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <BarChart3 className="mr-2" size={20} />
              Chat Analytics
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="p-0 h-auto"
            >
              <X size={20} />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="usage">Usage Patterns</TabsTrigger>
            <TabsTrigger value="topics">Popular Topics</TabsTrigger>
            <TabsTrigger value="feedback">Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Sessions</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-coffee">{analytics.totalSessions}</div>
                  <p className="text-xs text-muted-foreground">Unique conversations</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-coffee">{analytics.totalMessages}</div>
                  <p className="text-xs text-muted-foreground">Messages exchanged</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg Session Length</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-coffee">{analytics.averageSessionLength}</div>
                  <p className="text-xs text-muted-foreground">Messages per session</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="usage" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Hourly Usage Pattern</CardTitle>
                <CardDescription>Messages sent by hour of day</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.hourlyUsage}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="messages" fill="#8B4513" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Daily Usage Pattern</CardTitle>
                <CardDescription>Messages by day of the week</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.dailyUsage}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="messages" fill="#D2691E" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="topics" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Most Asked Questions</CardTitle>
                <CardDescription>Popular topic categories</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.topQuestions}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ question, percent }) => `${question} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {analytics.topQuestions.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feedback" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Response Ratings</CardTitle>
                <CardDescription>User feedback on AI responses</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.responseRatings}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ rating, percent }) => `${rating} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      <Cell fill="#22c55e" /> {/* Green for helpful */}
                      <Cell fill="#ef4444" /> {/* Red for unhelpful */}
                      <Cell fill="#6b7280" /> {/* Gray for no rating */}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}