import { useState } from "react";
import { Globe, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";

const LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹' },
  { code: 'pt', name: 'Português', flag: '🇵🇹' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' }
];

const TRANSLATIONS = {
  en: {
    welcome: "Welcome to Bean & Brew Café! ☕",
    welcomeText: "I'm your AI assistant, here to help with any questions about our menu, hours, location, or services. What would you like to know?",
    placeholder: "Ask me anything about Bean & Brew Café...",
    brewing: "Brewing your answer...",
    hours: "Hours",
    menu: "Menu", 
    location: "Location",
    wifi: "WiFi",
    breakfast: "Breakfast",
    coffee: "Coffee",
    lunch: "Lunch",
    payment: "Payment",
    studySpace: "Study Space"
  },
  es: {
    welcome: "¡Bienvenido a Bean & Brew Café! ☕",
    welcomeText: "Soy tu asistente de IA, aquí para ayudar con cualquier pregunta sobre nuestro menú, horarios, ubicación o servicios. ¿Qué te gustaría saber?",
    placeholder: "Pregúntame cualquier cosa sobre Bean & Brew Café...",
    brewing: "Preparando tu respuesta...",
    hours: "Horarios",
    menu: "Menú",
    location: "Ubicación", 
    wifi: "WiFi",
    breakfast: "Desayuno",
    coffee: "Café",
    lunch: "Almuerzo",
    payment: "Pago",
    studySpace: "Área de Estudio"
  },
  fr: {
    welcome: "Bienvenue au Bean & Brew Café! ☕",
    welcomeText: "Je suis votre assistant IA, ici pour vous aider avec toute question sur notre menu, nos horaires, notre emplacement ou nos services. Que souhaitez-vous savoir?",
    placeholder: "Demandez-moi n'importe quoi sur Bean & Brew Café...",
    brewing: "Préparation de votre réponse...",
    hours: "Horaires",
    menu: "Menu",
    location: "Emplacement",
    wifi: "WiFi",
    breakfast: "Petit-déjeuner",
    coffee: "Café",
    lunch: "Déjeuner",
    payment: "Paiement",
    studySpace: "Espace d'Étude"
  },
  de: {
    welcome: "Willkommen im Bean & Brew Café! ☕",
    welcomeText: "Ich bin Ihr KI-Assistent, hier um bei Fragen zu unserer Speisekarte, Öffnungszeiten, Standort oder Dienstleistungen zu helfen. Was möchten Sie wissen?",
    placeholder: "Fragen Sie mich alles über Bean & Brew Café...",
    brewing: "Ihre Antwort wird zubereitet...",
    hours: "Öffnungszeiten",
    menu: "Speisekarte",
    location: "Standort",
    wifi: "WLAN",
    breakfast: "Frühstück",
    coffee: "Kaffee",
    lunch: "Mittagessen",
    payment: "Bezahlung",
    studySpace: "Lernbereich"
  },
  // Add more languages as needed
};

interface LanguageSelectorProps {
  selectedLanguage: string;
  onLanguageChange: (language: string) => void;
  compact?: boolean;
}

export function LanguageSelector({ selectedLanguage, onLanguageChange, compact = false }: LanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  
  const selectedLang = LANGUAGES.find(lang => lang.code === selectedLanguage) || LANGUAGES[0];

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size={compact ? "sm" : "default"}
          className="flex items-center space-x-2 text-coffee hover:text-coffee/80"
        >
          {compact ? (
            <Globe size={16} />
          ) : (
            <>
              <span className="text-lg">{selectedLang.flag}</span>
              <span>{selectedLang.name}</span>
              <Globe size={16} />
            </>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-0" align="end">
        <Command>
          <CommandInput placeholder="Search languages..." />
          <CommandList>
            <CommandEmpty>No language found.</CommandEmpty>
            <CommandGroup>
              {LANGUAGES.map((language) => (
                <CommandItem
                  key={language.code}
                  value={language.code}
                  onSelect={() => {
                    onLanguageChange(language.code);
                    setOpen(false);
                  }}
                  className="flex items-center space-x-2 cursor-pointer"
                >
                  <span className="text-lg">{language.flag}</span>
                  <span className="flex-1">{language.name}</span>
                  {language.code === selectedLanguage && (
                    <Check size={16} className="text-coffee" />
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export function useTranslations(language: string = 'en') {
  const t = (key: string): string => {
    const langTranslations = TRANSLATIONS[language as keyof typeof TRANSLATIONS] || TRANSLATIONS.en;
    return langTranslations[key as keyof typeof langTranslations] || key;
  };

  return { t };
}