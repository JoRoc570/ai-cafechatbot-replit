import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema } from "@shared/schema";
import { getChatResponse } from "./services/openai";
import { z } from "zod";

const chatRequestSchema = z.object({
  message: z.string().min(1).max(1000),
  sessionId: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get chat messages for a session
  app.get("/api/chat/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json({ messages });
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Send a chat message and get AI response
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, sessionId } = chatRequestSchema.parse(req.body);

      // Save user message
      const userMessage = await storage.createChatMessage({
        sessionId,
        message,
        isUser: true,
      });

      // Get AI response
      const aiResponse = await getChatResponse(message);

      // Save AI response
      const aiMessage = await storage.createChatMessage({
        sessionId,
        message: aiResponse,
        isUser: false,
      });

      res.json({ 
        userMessage, 
        aiMessage,
        response: aiResponse 
      });
    } catch (error) {
      console.error("Error processing chat message:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data" });
      }
      
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process message" 
      });
    }
  });


  const httpServer = createServer(app);
  return httpServer;
}
