# replit.md

## Overview

This is a comprehensive AI-powered FAQ chatbot for "Bean & Brew Café" featuring an enhanced chat interface where customers can interact with a multilingual AI assistant. The application includes advanced features like analytics dashboard, voice input, theme customization, and smart contextual suggestions. Built with React for the frontend, Express.js for the backend, and in-memory storage for development efficiency.

## User Preferences

Preferred communication style: Simple, everyday language.
UI/UX preferences: Personable and café-themed messaging (e.g., "Brewing your answer..." instead of technical language).
AI response style: Balanced temperature (0.7) for friendly yet accurate responses.
Design preferences: Coffee-themed animations, glassmorphism effects, and professional responsive design.
Feature preferences: Multilingual support, analytics insights, voice input capabilities, and dark mode compatibility.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI primitives with custom styling (New York style variant)
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database serverless PostgreSQL
- **API Design**: RESTful endpoints for chat functionality
- **Session Management**: Simple session-based chat tracking
- **External Service**: OpenAI GPT-4o integration for AI responses

### Data Storage
- **Primary Database**: PostgreSQL via Neon Database
- **ORM**: Drizzle ORM for type-safe database operations
- **Migrations**: Drizzle Kit for schema management
- **Fallback Storage**: In-memory storage implementation for development

## Key Components

### Database Schema
- **Users Table**: Basic user management with username/password
- **Chat Messages Table**: Stores conversation history with session tracking
- **Validation**: Zod schemas for runtime type checking and validation

### API Endpoints
- `GET /api/chat/:sessionId` - Retrieve chat history for a session
- `POST /api/chat` - Send message and receive AI response

### Frontend Components
- **Enhanced Chat Interface**: Real-time chat UI with coffee-themed animations and message history
- **Analytics Dashboard**: Comprehensive usage patterns, popular questions, and user satisfaction metrics
- **Multilingual Support**: 10+ languages with smart language detection and localized interface
- **Voice Input**: Hands-free interaction capabilities with microphone integration
- **Theme System**: Dark/light mode toggle with coffee-themed color schemes
- **Dynamic Quick Actions**: Time-based contextual suggestions that adapt throughout the day
- **Message Reactions**: User feedback system with helpful/unhelpful ratings
- **Toast Notifications**: Enhanced user feedback with café-themed messaging
- **Responsive Design**: Mobile-first approach with glassmorphism effects and professional styling

### AI Integration
- **OpenAI Service**: GPT-4o model integration
- **Café Context**: Pre-configured with Bean & Brew Café information
- **Error Handling**: Graceful fallbacks for API failures

## Data Flow

1. **User Input**: Customer types message in chat interface
2. **Message Storage**: User message saved to database with session ID
3. **AI Processing**: Message sent to OpenAI with café context
4. **Response Storage**: AI response saved to database
5. **UI Update**: Both messages displayed in chat interface via React Query

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon Database
- **openai**: Official OpenAI API client
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first CSS framework
- **Drizzle Kit**: Database migration and schema management

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API authentication

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Database**: Drizzle Kit handles schema migrations

### Production Configuration
- Node.js runtime with ES modules
- PostgreSQL database via Neon Database
- Environment-based configuration for API keys
- Static file serving for React build

### Development Features
- Hot module replacement via Vite
- Replit integration with development banner
- Runtime error overlay for debugging
- Automatic type checking and validation

## Recent Changes (January 2025)

- **✓ Enhanced UI/UX**: Implemented coffee-themed animations, glassmorphism effects, and professional responsive design
- **✓ Multilingual Support**: Added 10+ languages with smart detection and localized interface elements
- **✓ Analytics Dashboard**: Created comprehensive usage tracking with charts for patterns, popular questions, and feedback
- **✓ Voice Input Capabilities**: Integrated microphone support for hands-free customer interactions
- **✓ Dark Mode & Themes**: Added complete theme system with coffee-inspired color schemes
- **✓ Smart Quick Actions**: Implemented time-based contextual suggestions that adapt throughout the day
- **✓ Message Reactions**: Added customer feedback system for rating AI response helpfulness
- **✓ Enhanced Typography**: Improved readability with customizable font sizes and better spacing
- **✓ Accessibility Features**: Added proper ARIA labels, focus states, and keyboard navigation
- **✓ Performance Optimizations**: Enhanced loading states, animations, and responsive behavior

The application follows a clean separation of concerns with shared TypeScript types between frontend and backend, ensuring type safety across the entire stack. The enhanced architecture now supports comprehensive customer engagement features while maintaining development efficiency and production readiness.